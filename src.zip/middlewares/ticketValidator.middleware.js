'user strict'
exports.validate = function (req, res, next) {
    next();
}
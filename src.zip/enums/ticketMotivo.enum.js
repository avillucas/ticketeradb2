}
export default ETicketMotivo = {
    desperfecto: "Desperfecto",
    cambioPlan: "Cambio de plan",
    baja: "Baja de plan",
    alta: "Alta de plan"
}
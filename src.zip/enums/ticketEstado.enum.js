export default TicketEstado = {
    demorado: "Demorado",
    pendiente: "Pendiente",
    resuelto: "Resuelto"
}
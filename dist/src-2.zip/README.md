# ticketeradb2
Proyecto para la materia base de datos 2, tema mongo db 

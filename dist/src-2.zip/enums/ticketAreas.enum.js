export default  ticketAreas  = {
    atencionCliente: "Atención al cliente",
    tecnico: "Servicio técnico",
    financieros: "Servicios financieros"
}
export default EOficinasTipo = {
    atencionCliente: "Atención al cliente",
    tecnico: "Servicio técnico"
}
'user strict'

var middleware = new Object();
/**
 * Procesa las validaciones de la creacion de un ticket
 * TODO completar 
 * @param {*} req 
 * @param {*} res 
 * @param {*} next 
 */
middleware.traerUno = function (req, res, next) {
    next();
    
};
/**
 * Procesa las validaciones de la creacion de un ticket
 * TODO completar 
 * @param {*} req 
 * @param {*} res 
 * @param {*} next 
 */
middleware.traerTodos = function (req, res, next) {
    next();
};
/**
 * Procesa las validaciones de la creacion de un ticket
 * TODO completar 
 * @param {*} req 
 * @param {*} res 
 * @param {*} next 
 */
middleware.crearUno = function (req, res, next) {
    next();
};
/**
 * Procesa las validaciones de la creacion de un ticket
 * TODO completar 
 * @param {*} req 
 * @param {*} res 
 * @param {*} next 
 */
middleware.modificarUno = function (req, res, next) {
    next();
};
/**
 * Procesa las validaciones de la creacion de un ticket
 * TODO completar 
 * @param {*} req 
 * @param {*} res 
 * @param {*} next 
 */
middleware.eliminarUno = function (req, res, next) {
    next();
};

module.exports.middleware = middleware;